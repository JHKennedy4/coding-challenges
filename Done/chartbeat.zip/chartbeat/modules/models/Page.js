var Page = (function () {

    function Page(model) {
        this.attributes = model;
    }

    return Page;
}());
