var $ = require('jquery-untouched');
var Backbone = require('backbone');
var PhotoCollection = require('./collections/Photos.js');
var PhotosView = require('./views/Photos.js');
var InputView = require('./views/Input.js');
var Nav = require('./views/navigation.js');
var AuthView = require('./views/AuthView.js');
var User = require('./models/user.js');
Backbone.$ = $;
var user;

var Router = Backbone.Router.extend({

    routes: {
        '': 'default',
        'sign/in': 'signIn',
        'sign/up': 'signUp',
        'photo/:id': 'showImage',
        'profile': 'userProfile',
        'profile/edit': 'editProfile'
    }

});

var routeMe = new Router();

routeMe.on("route:default", renderStream);
routeMe.on("route:signUp", renderSignUpPage);
routeMe.on("route:signIn", renderSignInPage);
routeMe.on("route:showImage", showImage);

Backbone.on("loggedin", function (aUser) {
    user = new User(aUser);
    console.log(user);
    routeMe.navigate("", {trigger: true});
});

Backbone.history.start();

function renderSignInPage() {
    sign({
        login: true
    });
}

function renderSignUpPage() {
    sign({
        login: false
    });
}

function sign(login) {
    console.log("sign in or up");
    if(user) {
        routeMe.navigate("", {trigger: true});
        return;
    }
    renderNav();
    var authView = new AuthView(login);
    authView.render();
    $('body').append(authView.el);
}

function showImage() {
    console.log("show image");
}


function renderNav () {
    $('body').empty();
    var nav;
    console.log(user);
    if(user) {
        nav =  new Nav(user);
    } else {
        nav =  new Nav();
    }
    nav.render();
    $('body').append(nav.el);
}

function renderStream () {
    renderNav();

    var photos = new PhotoCollection();
    var photosView = new PhotosView({collection: photos});

    photosView.listenTo(photos, 'reset', function () {
        $('body').append(photosView.el);
    });

    photos.sync();

    var input = new InputView();

    input.render();

    $('body').append(input.el);
}
