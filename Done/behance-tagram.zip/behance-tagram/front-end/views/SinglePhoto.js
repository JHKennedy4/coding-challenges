var Backbone = require('backbone');
var $ = require('jquery-untouched');
Backbone.$ = $;

var SinglePhotoTemplate = require('../templates/SinglePhoto.hbs');

var SinglePhoto = Backbone.View.extend({

  tagName: 'li',
  template: SinglePhotoTemplate,

  initialize: function (model) {
      this.model = model;
  },

  render: function() {
    this.$el.html(this.template(this.model.attributes));
    return this;
  }

});
module.exports = SinglePhoto;
