var Backbone = require('backbone');
var NavTemplate = require('../templates/navigation.hbs');

var Nav = Backbone.View.extend({
  initialize: function (user) {
      this.model = user;
      console.log("Nav: " + JSON.stringify(this.model));
  },


  template: NavTemplate,

  events: {
      "submit form": "upload"
  },

  upload: function () {
      $.post("/photo", function () {

      });

  },

  render: function() {
      if(this.model) {
          this.$el.html(this.template(this.model.attributes));
      }else {
          this.$el.html(this.template());
      }
      return this;
  }
});

module.exports = Nav;
