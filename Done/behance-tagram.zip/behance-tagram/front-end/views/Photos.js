var Backbone = require('backbone');
Backbone.$ = require('jquery-untouched');
Backbone.Marionette = require('backbone.marionette');
var PhotoView = require('../views/SinglePhoto.js');
var Photos = require('../collections/Photos.js');

var Photos = Backbone.Marionette.CollectionView.extend({

  tagName: 'ul',
  childView: PhotoView,
  initialize: function () {
      this.listenTo(this.collection, 'reset', function () {
          this.render();
          //console.log(this.el);
      });
  },
  render: function () {
      this.$el.empty();
      var view = this;

      this.collection.each(function (el) {
          view.$el.append(new view.childView(el).render().el);
      });
      return this;
  }

});
module.exports = Photos;
