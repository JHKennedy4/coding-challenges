var Backbone = require('backbone');
var $ = require('jquery-untouched');

var AuthTemplate = require('../templates/Auth.hbs');

var Auth = Backbone.View.extend({

  initialize: function (type) {
      this.type = type;
  },
  template: AuthTemplate,

  tagName: "div",
  className: "auth",

  events: {
      'submit form.create': "authenticate",
      'submit form.login': "authenticate"
  },


  authenticate: function (e) {

      var type;
      if(this.type.login === true) {
          type = "login";
      } else {
          type = "create";
      }
      e.preventDefault();
      e.stopPropagation();

      var user = $("form").serialize();
      $.post("/api/user/" + type, user)
      .done(function (user) {
          // Navigate
          Backbone.trigger("loggedin", user);
      })
      .error(function (error) {
          console.log(error);
      });
  },

  render: function() {
      this.$el.html(this.template(this.type));
      return this;
  }

});
module.exports = Auth;
