var Backbone = require('backbone');

var SinglePhoto = Backbone.Model.extend({
});
module.exports = SinglePhoto;
