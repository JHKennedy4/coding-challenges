var Backbone = require('backbone');

var User = Backbone.Model.extend({
});
module.exports = User;
