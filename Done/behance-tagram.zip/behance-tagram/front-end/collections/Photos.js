var Backbone = require('backbone');
var SinglePhoto = require('../models/SinglePhoto.js');
var $ = require('jquery-untouched');
var _ = require('underscore');

var Photos = Backbone.Collection.extend({

    model: SinglePhoto,

    initialize: function () {
        Backbone.on('filter', this.filter, this);
    },

    url: "/api/photo",

    sync: function () {
        var collection = this;
        var models = [];
        $.getJSON(this.url, function (data) {
            data.forEach(function (res) {
                models.push(new SinglePhoto(res));
            });
            collection.originalModels = models;
            collection.reset(models);
        });
    },

    filter: function (userInput) {

        var models = _.filter(this.originalModels, function (model) {
            return model.get('title').toLowerCase().indexOf(userInput.toLowerCase()) > -1;
        });

        this.reset(models);
        return this;
    }
});

module.exports = Photos;
