<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/


Route::get('/api/photo', 'PhotoController@getAll'); // A Done

Route::post('/api/user/create', 'UserController@create'); // B

Route::post('/api/user/login', 'UserController@login'); // C protected

Route::post('/api/user/{id}/upload-image', 'UploadController@saveImage'); // D protected

Route::delete('/api/photo/{id}', 'PhotoController@delete'); // E protected

Route::get('/api/photo/user/{id}', 'PhotoController@getByOwnerId'); // H

Route::put('/api/user/{id}/upload-profile-image', 'UploadController@saveProfileImage'); //F protected

/*
Route::put('/user/{id}/edit', 'UserController@edit'); // F protected

Route::get('/photo/{id}', 'PhotoController@getById'); // G
Route::post('/photo/{id}/comment', 'CommentController@postComment'); // G protected
// Route::get('/photo/{id}/comments', 'PhotoController@getComments'); // G

*/
Route::get('/', function()
{
    return View::make('index');
});
