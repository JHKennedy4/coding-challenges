<?php

class UserController extends BaseController {

    public function create() {
        $email = Input::get("email");
        $password = Hash::make(Input::get("password"));
        $first_name = Input::get("first_name");
        $last_name = Input::get("last_name");

        $user = new User([
            "email" => $email,
            "password" => $password,
            "first_name" => $first_name,
            "last_name" => $last_name
        ]);

        try {
            $user->save();
        } catch (PDOException $e) {
            return Response::make($e->getMessage(), 400);
        }

        return $user;
    }

    public function login() {
        if (Auth::check()) {
            return Auth::user();
        }

        $email = Input::get("email");
        $password = Input::get("password");
        if (Auth::attempt([
            'email' => $email,
            "password" => $password
        ])) {
            return Auth::user();
        } else {
            $error = View::make("Error", [
                "error" => "Auth Error",
                "message" => "Invalid credentials"
            ]);
            return Response::make($error, 403);
        }
    }

}
