<?php

class UploadController extends BaseController {

    public function getImagesDirectory() {
        return public_path() . '/images/';
    }

    public function saveImage($id, $isProfile = false) {

        $user_id = $id;

        if(!Auth::check() || Auth::id() != $user_id) {
            $error = View::make("Error", [
                "error" => "Auth Error",
                "message" => "access denied"
            ]);
            return Response::make($error, 403);
        }

        if(!Input::hasFile('photo')) {
            return View::make("Error", [
                "error" => "Upload Error",
                "message" => "File not found"
            ]);
        }

        $file = Input::file('photo');
        $file_extension = $file->getClientOriginalExtension();

        if(!($file_extension !== "png" ||
           $file_extension !== "gif" ||
           $file_extension !== "jpg")) {

           return View::make("Error", [
               "error" => "Upload Error",
               "message" => "Invalid extension"
           ]);

        }

        $photo_location = $file->getRealPath();

        $photo_path = md5_file($photo_location) . "." . $file_extension;

        $file->move($this->getImagesDirectory(), $photo_path);

        $title = "test";

        //User::find($user_id)->
        $photo = Photo::firstOrCreate([
            "title" => $title,
            "path" => $photo_path,
            "owner_id" => $user_id
        ]);


        // return new photo view
        return $photo;
    }

    public function saveProfileImage($id) {
        $result = $this->saveImage($id, true);
        return $result;

    }

}
