<?php

class PhotoController extends BaseController {

    public function getAll() {
        $photos = Photo::all();
        return $photos;
    }

    public function delete($id) {
        $photo = Photo::find($id);
        if(!$photo) {
            return Response::make("Photo not found", 400);
        }

        if(Auth::check() && Auth::id() == $photo->getAttribute("owner_id")) {
            $photo->delete();
        } else {
            $error = View::make("Error", [
                "error" => "Auth Error",
                "message" => "access denied"
            ]);
            return Response::make($error, 403);
        }

    }

    public function getByOwnerId($id) {
        return Photo::where('owner_id', "=", $id)->get();
    }

}
