<html>
<head>
  <title>Indiegogo</title>
  <link rel="icon"
      type="image/png"
      href="favicon.png">
  <link rel="stylesheet" href="style.css">
</head>
  <body>
  <script src="bundle.js"></script>
  </body>
</html>
