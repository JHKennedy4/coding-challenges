{
    "error": "<?php echo $error; ?>",
    "message": "<?php echo $message; ?>"
}
