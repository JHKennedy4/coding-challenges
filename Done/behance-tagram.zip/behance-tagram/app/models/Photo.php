<?php

class Photo extends Eloquent {

    protected $table = 'photos';
    protected $fillable = ['title', 'path', 'owner_id'];

}
