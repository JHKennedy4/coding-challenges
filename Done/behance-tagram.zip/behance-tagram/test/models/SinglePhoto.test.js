var SinglePhoto = require('../../front-end/models/SinglePhoto.js'),
    chai = require('chai'),
    should = chai.should(),
    response = require('../response.js').response;

describe("Models/SinglePhoto", function () {

    it("should initialize", function () {
        var Photo = new SinglePhoto(response.response[0]);

        Photo.get('id').should.equal(1009068);
    });
});
