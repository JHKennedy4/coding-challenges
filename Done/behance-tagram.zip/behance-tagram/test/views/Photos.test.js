var PhotosView = require('../../front-end/views/Photos.js'),
    PhotosCollection = require('../../front-end/collections/Photos.js'),
    chai = require('chai'),
    should = chai.should(),
    sinon = require('sinon'),
    SinglePhoto = require('../../front-end/models/SinglePhoto.js'),
    SinglePhotoView = require('../../front-end/views/SinglePhoto.js'),
    response = require('../response.js').response;

describe("views/Photos", function (){

    xit("should update the view on collection's change event", function () {

        var collection = new PhotosCollection(response);
        var view = new PhotosView({collection: collection});

        view.render();

        collection.reset([response.response[0], response.response[2]]);

        view.$el.find('li').length.should.equal(2);

    });

    xit("should accurately render a collection of views from a sync call", function (done) {

        var xhr = sinon.useFakeXMLHttpRequest();
        var request = null;
        xhr.onCreate = function (xhr) {
            request = xhr;
        };

        var Photo = new PhotosCollection();
        var PhotoView = new PhotosView({collection: Photo});

        var expectedHtml = "<ul>\n";
        response.response.forEach(function (res) {
            var singlePhoto = new SinglePhoto(res);
            var singlePhotoView = new SinglePhotoView(singlePhoto);

            singlePhotoView.render();
            expectedHtml += singlePhotoView.$el.html() + "\n";
        });
        expectedHtml += "</ul>";

        PhotoView.listenTo(Photo, 'reset', function () {

            PhotoView.render();
            PhotoView.el.should.equal(expectedHtml);

            done();
        });


        Photo.sync();

        request.respond(200, {'Content-Type': 'text/plain'}, JSON.stringify(response));

    });


});
