var SinglePhotoView = require('../../front-end/views/SinglePhoto.js'),
    SinglePhoto = require('../../front-end/models/SinglePhoto.js'),
    chai = require('chai'),
    should = chai.should(),
    response = require('../response.js').response;

describe("Views/SinglePhoto", function (){

    xit("should render with the given model", function () {
        var Photo = new SinglePhoto(response.response[0]);
        var PhotoView = new SinglePhotoView(Photo);

     var expectedHTML = ('<img alt="TimeLash - das erste Event für Fans von Doctor Who image" src="http://res.cloudinary.com/indiegogo-media-prod-cld/image/upload/t_iPhone_standard/v1418648322/gjfoqaqb0pwvii0vwnvx.jpg">\n' +
               '<div class="title">TimeLash - das erste Event für Fans von Doctor Who</div>\n' +
               '<div class="tagline">Stargäste aus \"Doctor Who\" * Panels &amp; Interviews * Fan-Aktionen * Cosplay</div>\n').replace(/ /g,'');


        PhotoView.render().$el.html().replace(/ /g,'')
            .should
            .equal(expectedHTML);
    });
});
