var PhotoCollection = require('../../front-end/collections/Photos.js'),
    chai = require('chai'),
    should = chai.should(),
    sinon = require('sinon'),
    Backbone = require('backbone'),
    _ = require('underscore');


describe("Collections/Photos", function () {

    var PhotoCollection;
    var xhr;
    var request;

    beforeEach(function () {
        xhr = sinon.useFakeXMLHttpRequest();
        request = null;

        xhr.onCreate = function ( xhr ) {
            request = xhr;
        };

        PhotoCollection = new PhotoCollection();
        PhotoCollection.sync();

        request.respond(200, {'Content-Type': 'text/plain'}, JSON.stringify(require('../response.js').response));

    });

    afterEach(function () {
        xhr = null;
        PhotoCollection = null;
    });


    it("should filter by title on filter event", function () {

        Backbone.trigger('filter', 'timelash');
        PhotoCollection.models[0].get("title").should.equal("TimeLash - das erste Event für Fans von Doctor Who");

    })

    it("should filter the collection by title", function () {

        var collection = PhotoCollection.filter("TimeLash");

        PhotoCollection.models.length.should.equal(1);
         PhotoCollection.models[0].get("title").should.equal("TimeLash - das erste Event für Fans von Doctor Who");

    });

    it("should return the correct url for the collection", function () {

        var PhotoCollection =  new PhotoCollection();

        PhotoCollection.url.should.equal("https://api.indiegogo.com/1/Photos.json?api_token=e377270bf1e9121da34cb6dff0e8af52a03296766a8e955c19f62f593651b346");

    });

    it("should initialize with values from the server", function () {
      
        PhotoCollection.models.length.should.be.greaterThan(0);
    });

});
